/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import clinica.RegistroCovid_19;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import modeloDAO.ClinicaDAO;
import modeloDAO.PacienteDAO;
import modeloVO.PacienteVO;
import modeloDAO.Conexion;
import modeloDAO.PersonalSaludDAO;
import modeloVO.ClinicaVO;
import modeloVO.PersonalSaludVO;
import vista.Formulario;
import vista.RegistroPaciente;
import vista.RegistroPersonal;

/**
 *
 * @author Eduard
 */
public class Controlador implements ActionListener {

    private Formulario formulario = null;
    private RegistroPaciente registroPaciente;
    private RegistroPersonal registroPersonalSalud;
    private PacienteDAO pacienteDao;
    private PersonalSaludDAO personalDAO;
    private RegistroCovid_19 r;
    private ClinicaDAO clinicaDao;
    private ClinicaVO clinicaVO;

    public Controlador(RegistroCovid_19 registro) {
        super();
        formulario = new Formulario();
        registroPaciente = new RegistroPaciente();
        registroPersonalSalud = new RegistroPersonal();
        r = registro;
        actionListener(this);
        clinicaDao = new ClinicaDAO();
        pacienteDao = new PacienteDAO();
        personalDAO = new PersonalSaludDAO();
        
        clinicaVO = new ClinicaVO();

        System.out.println("el constructor de controlador sirve");
    }

    private void actionListener(ActionListener controlador) {
        System.out.println("el action listener sirve ");

        formulario.jButtonRegistrarPaciente.addActionListener(controlador);
        formulario.jButtonRegistrarPerspnal.addActionListener(controlador);
        registroPaciente.jButtonRegistrar.addActionListener(controlador);
        registroPersonalSalud.jButtonGuardar.addActionListener(controlador);
        formulario.jButtonBuscar.addActionListener(controlador);
        formulario.jButtonActualizar.addActionListener(controlador);
        formulario.jButtonEstadisticas.addActionListener(controlador);
        registroPaciente.jButtonCerrar.addActionListener(controlador);
        registroPersonalSalud.jButtonSalir.addActionListener(controlador);
    }
    public boolean isNumeric(String cadena) {
try {
Double.parseDouble(cadena);
return true;
} catch (NumberFormatException ex) {
return false;
}
}

    @Override
    public void actionPerformed(ActionEvent e) {

        
        if (e.getActionCommand().equals("Registrar Paciente")) {
            try {
                clinicaDao.guardar(Conexion.obtener(), r);
            } catch (SQLException | ClassNotFoundException ex) {
                Logger.getLogger(Controlador.class.getName()).log(Level.SEVERE, null, ex);
            }
            System.out.println("el boton registrar paciente sirve ");
            registroPaciente.setVisible(true);
            formulario.setVisible(false);
        }

        if (e.getActionCommand().equals("REGISTRAR ")) {
            System.out.println("el boton registrar 2 sirve ");

            String documento = this.registroPaciente.jTextFieldDocumento.getText();
            String nombre = this.registroPaciente.jTextFieldNombre.getText();
            String direccion = this.registroPaciente.jTextFieldDireccion.getText();
            String telefono = this.registroPaciente.jTextFieldTelefono.getText();
            String genero = (String) this.registroPaciente.jComboBoxGenero.getSelectedItem();
            Date fechaNacimiento = this.registroPaciente.jDateChooserFechaNacimiento.getDate();
            String estado = (String) this.registroPaciente.jComboBoxEstasoPaciente.getSelectedItem();
            String lugarProcedencia = this.registroPaciente.jTextFieldLugarProcedencia.getText();
            Date fechaDeteccion = this.registroPaciente.jDateChooserFechaDeteccion.getDate();
            String tratado = (String) this.registroPaciente.jComboBoxProceso.getSelectedItem();
//            String personasPosibleContacto = "";
            String personasPosibleContacto = this.registroPaciente.jTextFieldDocumentoContacto1.getText() + "    " + this.registroPaciente.jTextFieldNombreContacto1.getText() + "\n"
                    + this.registroPaciente.jTextFieldDocumentoContacto2.getText() + "    " + this.registroPaciente.jTextFieldNombreContacto2.getText() + "\n"
                    + this.registroPaciente.jTextFieldDocumentoContacto3.getText() + "    " + this.registroPaciente.jTextFieldNombreContacto3.getText() + "\n"
                    + this.registroPaciente.jTextFieldDocumentoContacto4.getText() + "    " + this.registroPaciente.jTextFieldNombreContacto4.getText() + "\n"
                    + this.registroPaciente.jTextFieldDocumentoContacto5.getText() + "    " + this.registroPaciente.jTextFieldNombreContacto5.getText();
            System.out.println("el boton registar paciente 3 sirve");

        
   

   // Validar el campo "documento"
   if (!isNumeric(documento)) {
      JOptionPane.showMessageDialog(this.registroPaciente, "El documento debe ser un número.", "Error", JOptionPane.ERROR_MESSAGE);
      return;
   }

   // Validar el campo "telefono"
   if (!isNumeric(telefono)) {
      JOptionPane.showMessageDialog(this.registroPaciente, "El teléfono debe ser un número.", "Error", JOptionPane.ERROR_MESSAGE);
      return;
   }

   // Validar el campo "fechaNacimiento"
   if (fechaNacimiento == null) {
      JOptionPane.showMessageDialog(this.registroPaciente, "La fecha de nacimiento no puede estar vacía.", "Error", JOptionPane.ERROR_MESSAGE);
      return;
   }
   //validar que no hayan campo de texto vacios
   if (documento.equalsIgnoreCase("")) {
      JOptionPane.showMessageDialog(this.registroPaciente, "campo de documento vacio .", "Error", JOptionPane.ERROR_MESSAGE);
      return;
   }
    if (nombre.equalsIgnoreCase("")) {
      JOptionPane.showMessageDialog(this.registroPaciente, "campo de nombre vacio .", "Error", JOptionPane.ERROR_MESSAGE);
      return;
   }
     if (direccion.equalsIgnoreCase("")) {
      JOptionPane.showMessageDialog(this.registroPaciente, "campo de direccion vacio .", "Error", JOptionPane.ERROR_MESSAGE);
      return;
   }
      if (telefono.equalsIgnoreCase("")) {
      JOptionPane.showMessageDialog(this.registroPaciente, "campo de telefono vacio .", "Error", JOptionPane.ERROR_MESSAGE);
      return;
   }
       if (lugarProcedencia.equalsIgnoreCase("")) {
      JOptionPane.showMessageDialog(this.registroPaciente, "campo de lugar de Procedencia vacio .", "Error", JOptionPane.ERROR_MESSAGE);
      return;
   }

            // Crear el objeto PacienteVO con los datos ingresados por el usuario
            PacienteVO paciente = new PacienteVO(lugarProcedencia, fechaDeteccion, tratado, personasPosibleContacto, documento, nombre, direccion, telefono, genero, fechaNacimiento, estado);
            String nombreClinica = (String) this.formulario.jComboBox1Clinica.getSelectedItem();
           clinicaVO=r.buscarClinicaPorNombre(nombreClinica);

            try {

                pacienteDao.guardar(Conexion.obtener(), paciente,clinicaVO );
            } catch (SQLException | ClassNotFoundException ex) {
                Logger.getLogger(Controlador.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        if (e.getActionCommand().equals("Registrar Personal de Salud")) {
            registroPersonalSalud.setVisible(true);
            formulario.setVisible(false);
        }
         if (e.getActionCommand().equals("SALIR")) {
            registroPersonalSalud.setVisible(false);
            formulario.setVisible(true);
         }
         if (e.getActionCommand().equals("CERRAR")) {
            registroPaciente.setVisible(false);
            formulario.setVisible(true);
         }
        if (e.getActionCommand().equals("GUARDAR")) {
            String documento = this.registroPersonalSalud.jTextFieldDocumentoPer.getText();
            String nombre = this.registroPersonalSalud.jTextFieldNombrePer.getText();
            String direccion = this.registroPersonalSalud.jTextFieldDireccion.getText();
            String telefono = this.registroPersonalSalud.jTextFieldTelefono.getText();
            String genero = (String) this.registroPersonalSalud.jComboBoxGenero.getSelectedItem();
            Date fechaNacimiento = this.registroPersonalSalud.jDateChooserFechaNacimiento.getDate();
            String estado = (String) this.registroPersonalSalud.jComboBoxEstaso.getSelectedItem();
            String especialidad = (String) this.registroPersonalSalud.jComboBoxEspecialidad.getSelectedItem();

            // Validar el campo "documento"
   if (!isNumeric(documento)) {
      JOptionPane.showMessageDialog(this.registroPaciente, "El documento debe ser un número.", "Error", JOptionPane.ERROR_MESSAGE);
      return;
   }

   // Validar el campo "telefono"
   if (!isNumeric(telefono)) {
      JOptionPane.showMessageDialog(this.registroPaciente, "El teléfono debe ser un número.", "Error", JOptionPane.ERROR_MESSAGE);
      return;
   }

   // Validar el campo "fechaNacimiento"
   if (fechaNacimiento == null) {
      JOptionPane.showMessageDialog(this.registroPaciente, "La fecha de nacimiento no puede estar vacía.", "Error", JOptionPane.ERROR_MESSAGE);
      return;
   }
   //validar que no hayan campo de texto vacios
   if (documento.equalsIgnoreCase("")) {
      JOptionPane.showMessageDialog(this.registroPaciente, "campo de documento vacio .", "Error", JOptionPane.ERROR_MESSAGE);
      return;
   }
    if (nombre.equalsIgnoreCase("")) {
      JOptionPane.showMessageDialog(this.registroPaciente, "campo de nombre vacio .", "Error", JOptionPane.ERROR_MESSAGE);
      return;
   }
     if (direccion.equalsIgnoreCase("")) {
      JOptionPane.showMessageDialog(this.registroPaciente, "campo de direccion vacio .", "Error", JOptionPane.ERROR_MESSAGE);
      return;
   }
      if (telefono.equalsIgnoreCase("")) {
      JOptionPane.showMessageDialog(this.registroPaciente, "campo de telefono vacio .", "Error", JOptionPane.ERROR_MESSAGE);
      return;
   }
     
            String clinica = (String) this.formulario.jComboBox1Clinica.getSelectedItem();
            String nombreClinica = (String) this.formulario.jComboBox1Clinica.getSelectedItem();
            clinicaVO=r.buscarClinicaPorNombre(nombreClinica);

            // Crear el objeto PersonalSaludVO con los datos ingresados por el usuario
            PersonalSaludVO personalSalud = new PersonalSaludVO(especialidad, documento, nombre, direccion, telefono, genero, fechaNacimiento, estado,nombreClinica);
            try {
                personalDAO.guardar(Conexion.obtener(), personalSalud,  clinicaVO);
            } catch (SQLException ex) {
                Logger.getLogger(Controlador.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Controlador.class.getName()).log(Level.SEVERE, null, ex);
            }
            System.out.println("el boton guardar personal salud sirve");
            
        }
        if (e.getActionCommand().equals("Buscar")) {
            
            String documentoBuscar =this.formulario.jTextFieldDocumentoBusqueda.getText();
            PersonalSaludVO personalSalud= new PersonalSaludVO();
    
            try {
                personalSalud = personalDAO.buscar(Conexion.obtener(),documentoBuscar);
            } catch (SQLException | ClassNotFoundException ex) {
                Logger.getLogger(Controlador.class.getName()).log(Level.SEVERE, null, ex);
            }
            String mostrar="Nombre: "+personalSalud.getNombre()+"  Especialidad: "+personalSalud.getEspecialidad()+ "\n"+"Estado: "+personalSalud.getEstado();
            formulario.jTextAreaMostrarPersonal.setText(mostrar);
           
            
        }
         if (e.getActionCommand().equals("Actualizar")) {
             String documentoBuscar =this.formulario.jTextFieldDocumentoBusqueda.getText();
             String estado =(String) formulario.jComboBoxActualizarEstado.getSelectedItem();
             String nombreClinica = (String) this.formulario.jComboBox1Clinica.getSelectedItem();
            clinicaVO=r.buscarClinicaPorNombre(nombreClinica);
            try {
                personalDAO.actualizarEstado(Conexion.obtener(),  documentoBuscar, estado,clinicaVO);
                
               formulario.jTextAreaMostrarPersonal.setText("");
               formulario.jTextAreaMostrarPersonal.setText("El estado del personal de salud ha sido actualizado...");
                System.out.println("el boton actualizar personal salud sirve");
            } catch (SQLException ex) {
                Logger.getLogger(Controlador.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Controlador.class.getName()).log(Level.SEVERE, null, ex);
            }
         }
         
          if (e.getActionCommand().equals("Mostrar estadisticas")) {
              
               String mostrar="";
            try {
                mostrar = clinicaDao.contarEstados();
            } catch (SQLException ex) {
                Logger.getLogger(Controlador.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Controlador.class.getName()).log(Level.SEVERE, null, ex);
            }
              formulario.jTextAreaEstadisticas.setText(mostrar);
              System.out.println("el boton estadisticas sirve ");
          }
    }

}
