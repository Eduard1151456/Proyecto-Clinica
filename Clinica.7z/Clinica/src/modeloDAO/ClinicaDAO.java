/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modeloDAO;
import clinica.RegistroCovid_19;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.sql.ResultSet;

/**
 *
 * @author Eduard
 */

public class ClinicaDAO {
    public void guardar(Connection conexion, RegistroCovid_19 registro) throws SQLException {
   try {
      PreparedStatement consulta = (PreparedStatement) conexion.prepareStatement("INSERT INTO clinica (nombre,direccion) VALUES (?, ?)");
      consulta.setString(1, registro.getClinica().get(0).getNombre());
      consulta.setString(2, registro.getClinica().get(0).getDireccion());
      
      consulta.executeUpdate();
      
   } catch (SQLException ex) {
      throw new SQLException(ex);
   }
     try {
      PreparedStatement consulta = (PreparedStatement) conexion.prepareStatement("INSERT INTO clinica (nombre,direccion) VALUES (?, ?)");
      consulta.setString(1, registro.getClinica().get(1).getNombre());
      consulta.setString(2, registro.getClinica().get(1).getDireccion());
      
      consulta.executeUpdate();
      
   } catch (SQLException ex) {
      throw new SQLException(ex);
   }
        try {
      PreparedStatement consulta = (PreparedStatement) conexion.prepareStatement("INSERT INTO clinica (nombre,direccion) VALUES (?, ?)");
      consulta.setString(1, registro.getClinica().get(2).getNombre());
      consulta.setString(2, registro.getClinica().get(2).getDireccion());
      
      consulta.executeUpdate();
      
   } catch (SQLException ex) {
      throw new SQLException(ex);
   }
           try {
      PreparedStatement consulta = (PreparedStatement) conexion.prepareStatement("INSERT INTO clinica (nombre,direccion) VALUES (?, ?)");
      consulta.setString(1, registro.getClinica().get(3).getNombre());
      consulta.setString(2, registro.getClinica().get(3).getDireccion());
      
      consulta.executeUpdate();
      
   } catch (SQLException ex) {
      throw new SQLException(ex);
   }
              try {
      PreparedStatement consulta = (PreparedStatement) conexion.prepareStatement("INSERT INTO clinica (nombre,direccion) VALUES (?, ?)");
      consulta.setString(1, registro.getClinica().get(4).getNombre());
      consulta.setString(2, registro.getClinica().get(4).getDireccion());
      
      consulta.executeUpdate();
      
   } catch (SQLException ex) {
      throw new SQLException(ex);
   }
                 try {
      PreparedStatement consulta = (PreparedStatement) conexion.prepareStatement("INSERT INTO clinica (nombre,direccion) VALUES (?, ?)");
      consulta.setString(1, registro.getClinica().get(0).getNombre());
      consulta.setString(2, registro.getClinica().get(0).getDireccion());
      
      consulta.executeUpdate();
      
   } catch (SQLException ex) {
      throw new SQLException(ex);
   }
}
    
    public String contarEstados() throws SQLException, ClassNotFoundException {
   Connection conexion = null;
   PreparedStatement consulta = null;
   ResultSet resultados = null;
   StringBuilder sb = new StringBuilder();
   Map<String, Integer> estados = new HashMap<>();
   
   try {
      conexion = Conexion.obtener();
      
      // Consultar estados en la tabla "personal_salud"
      consulta = conexion.prepareStatement("SELECT estado, COUNT(*) FROM personal_salud GROUP BY estado");
      resultados = consulta.executeQuery();
      
      while (resultados.next()) {
         String estado = resultados.getString("estado");
         int cantidad = resultados.getInt(2);
         if (estados.containsKey(estado)) {
            cantidad += estados.get(estado);
         }
         estados.put(estado, cantidad);
      }
      
      // Consultar estados en la tabla "paciente"
      consulta = conexion.prepareStatement("SELECT estado, COUNT(*) FROM paciente GROUP BY estado");
      resultados = consulta.executeQuery();
      
      while (resultados.next()) {
         String estado = resultados.getString("estado");
         int cantidad = resultados.getInt(2);
         if (estados.containsKey(estado)) {
            cantidad += estados.get(estado);
         }
         estados.put(estado, cantidad);
      }
      
      // Construir el string con la información de los estados
      sb.append("Estados:\n");
      sb.append("SOSPECHOSO: ").append(estados.getOrDefault("SOSPECHOSO", 0)).append("\n");
      sb.append("POSITIVO: ").append(estados.getOrDefault("POSITIVO", 0)).append("\n");
      sb.append("NEGATIVO: ").append(estados.getOrDefault("NEGATIVO", 0)).append("\n");
      sb.append("RECUPERADO: ").append(estados.getOrDefault("RECUPERADO", 0)).append("\n");
      sb.append("MUERTO: ").append(estados.getOrDefault("MUERTO", 0)).append("\n");
      
      return sb.toString();
   } catch (SQLException ex) {
      throw new SQLException(ex);
   } finally {
      if (resultados != null) {
         resultados.close();
      }
      if (consulta != null) {
         consulta.close();
      }
      if (conexion != null) {
         conexion.close();
      }
   }
}
    
}
