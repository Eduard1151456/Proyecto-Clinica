/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modeloVO;

import java.util.Date;

/**
 *
 * @author Eduard
 */
public class PersonalSaludVO extends  PersonaVO {
    
    private String especialidad;
    private String idClinica;

    public PersonalSaludVO() {
        
    }

    public PersonalSaludVO(String especialidad, String documento, String nombre, String direccion, String telefono, String genero, Date fechaNacimiento, String estado,String nombreCli) {
        super(documento, nombre, direccion, telefono, genero, fechaNacimiento, estado);
        this.especialidad = especialidad;
        this.idClinica=nombreCli;
    }

    public String getIdClinica() {
        return idClinica;
    }

    public void setIdClinica(String idClinica) {
        this.idClinica = idClinica;
    }

    
    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }
    

    
    
    
}
